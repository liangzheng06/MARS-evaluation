classdef LearnAlgo < handle
    %LEARNALGO Summary of this class goes here
    %   Detailed explanation goes here
    
    properties

    end
    
    methods
        function obj = LearnAlgo(p)

        end
        
        function learnPairwise(obj,X,idxa,idxb,matches)
            
        end
        
        function learn(obj,X,y)
            
        end
        
        function d = dist(obj, X, idxa,idxb)
            
        end
    end
    
end

