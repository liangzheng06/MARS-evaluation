function v = vec(a)

v = a(:);
